import { CLEAR_STORE } from './types'

export const clearStore = () => {
  return {
    type: CLEAR_STORE
  }
}
